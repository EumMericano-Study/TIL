# CSV: Comma Separated Values 형태로 저장

import csv

def save_to_file(jobs):
  # open(): 파일을 열지만 자료가 없으면 만들어준다
  file = open("jobs.csv", mode="w", encoding='utf-8')
  writer = csv.writer(file)
  writer.writerow(["title","company","location","apply_link"])
  for job in jobs:
    # dictionary -> values로 값만 불러온다
    writer.writerow(list(job.values()))
  return
